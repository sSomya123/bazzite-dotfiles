### [bashtop](https://github.com/aristocratos/bashtop)

#### Install using Git

If you are a git user, you can install the theme and keep up to date by cloning the repo:

    git clone https://github.com/dracula/bashtop.git

#### Install manually

Download using the [GitHub .zip download](https://github.com/dracula/bashtop/archive/master.zip) option and unzip them.

#### Activating theme

1. Copy `dracula.theme` to `~/.config/bashtop/user_themes/`
2. Start bashtop, press `m` for the menu, go to options, *"Color theme"* and set dracula as the theme.
3. Enjoy :)
